import Detail from "../Detail/Detail";

export const Home = () => {
  return (
    <>
      <div className="">
        <Detail />
      </div>
    </>
  );
};
